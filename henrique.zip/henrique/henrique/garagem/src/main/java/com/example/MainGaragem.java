package com.example;

public class MainGaragem {

    public static void main(String[] args) {

        // Criar a garagem
        Garagem garagem = new Garagem();

        // Criar os veículos
        Carro carro1 = new Carro(
                "BMW", "M3", "Preto",
                5, 4,
                "Gasolina", 3.0, 510,
                2024, 15000, 95000,
                250,
                "Automática", 8,
                1730, 4.79, 1.43, 1.90,
                "Sedan"
        );

        Mota mota1 = new Mota(
                "Yamaha", "MT-07", "Azul",
                2,
                "Gasolina", 689, 74,
                2024, 8000, 9500,
                220,
                "Manual", 6,
                184, 2.14, 1.09, 0.75,
                "Naked"
        );

        barco barco1 = new barco(
                "Bayliner", "VR6", "Branco",
                8, 1,
                "Gasolina", 4.5, 300,
                2023, 120, 85000,
                45,
                "Motor de popa",
                2200, 6.7, 0.9, 2.5,
                "Lancha"
        );

        Carro carro2 = new Carro(
                "Audi", "RS3", "Cinzento",
                5, 4,
                "Gasolina", 2.5, 400,
                2023, 20000, 78000,
                290,
                "Automática", 7,
                1600, 4.39, 1.41, 1.85,
                "Hatchback"
        );

        Mota mota2 = new Mota(
                "Honda", "CBR600RR", "Vermelho",
                2,
                "Gasolina", 599, 118,
                2022, 12000, 11000,
                260,
                "Manual", 6,
                194, 2.03, 1.11, 0.69,
                "Desportiva"
        );

        // Garagem vazia
        garagem.mostrarGaragem();

        // Adicionar veículos
        System.out.println("\n--- A adicionar veículos ---");
        garagem.adicionarVeiculo(carro1);
        garagem.adicionarVeiculo(mota1);
        garagem.adicionarVeiculo(barco1);

        garagem.mostrarGaragem();

        // Encher a garagem
        System.out.println("\n--- A encher a garagem ---");
        garagem.adicionarVeiculo(carro2);
        garagem.adicionarVeiculo(mota2);

        // Tentar adicionar com a garagem cheia
        System.out.println("\n--- A tentar adicionar com a garagem cheia ---");
        garagem.adicionarVeiculo(new Mota(
                "Ducati", "Monster", "Vermelho",
                2,
                "Gasolina", 937, 111,
                2024, 3000, 13500,
                240,
                "Manual", 6,
                188, 2.15, 1.05, 0.80,
                "Naked"
        ));

        garagem.mostrarGaragem();

        // Remover veículos
        System.out.println("\n--- A remover o veículo do lugar 2 ---");
        garagem.removerVeiculo(2);

        System.out.println("\n--- A tentar remover um lugar inválido ---");
        garagem.removerVeiculo(9);

        garagem.mostrarGaragem();

        // Consultas
        System.out.println("\nVeículos na garagem: " + garagem.getQuantidadeAtual());
        System.out.println("Lugares disponíveis: " + garagem.getLugaresDisponiveis());
    }
}