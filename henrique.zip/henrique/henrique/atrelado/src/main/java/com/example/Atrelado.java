package com.example;

public class Atrelado {

    private String marca;
    private String modelo;
    private double peso;
    private double comprimento;
    private double largura;
    private double capacidadeCarga;
    private boolean ligadoAoBarco;

    public Atrelado(
            String marca,
            String modelo,
            double peso,
            double comprimento,
            double largura,
            double capacidadeCarga) {

        this.marca = marca;
        this.modelo = modelo;
        this.peso = peso;
        this.comprimento = comprimento;
        this.largura = largura;
        this.capacidadeCarga = capacidadeCarga;

        this.ligadoAoBarco = false;
    }

    public void ligarAoBarco() {

        if (!ligadoAoBarco) {
            ligadoAoBarco = true;
            System.out.println("O atrelado foi ligado ao barco.");
        } else {
            System.out.println("O atrelado já está ligado ao barco.");
        }
    }

    public void desligarDoBarco() {

        if (ligadoAoBarco) {
            ligadoAoBarco = false;
            System.out.println("O atrelado foi desligado do barco.");
        } else {
            System.out.println("O atrelado já está desligado do barco.");
        }
    }

    public void mostrarInformacoes() {

        System.out.println("================================");
        System.out.println("       INFORMAÇÕES DO ATRELADO");
        System.out.println("================================");

        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Comprimento: " + comprimento + " m");
        System.out.println("Largura: " + largura + " m");
        System.out.println("Capacidade de carga: " + capacidadeCarga + " kg");

        if (ligadoAoBarco) {
            System.out.println("Estado: Ligado ao barco");
        } else {
            System.out.println("Estado: Não ligado ao barco");
        }

        System.out.println("================================");
    }
}