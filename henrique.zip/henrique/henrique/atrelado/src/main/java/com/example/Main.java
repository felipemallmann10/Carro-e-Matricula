package com.example;

public class Main {

    public static void main(String[] args) {

        // Criar o objeto atrelado
        Atrelado atrelado1 = new Atrelado(
                "Nautilus",
                "NT-750",
                350,
                6.5,
                2.3,
                750
        );

        // Mostrar informações iniciais
        atrelado1.mostrarInformacoes();

        // Testar o comportamento do atrelado
        atrelado1.desligarDoBarco();   // já está desligado

        atrelado1.ligarAoBarco();

        atrelado1.ligarAoBarco();      // já está ligado

        atrelado1.mostrarInformacoes();

        atrelado1.desligarDoBarco();

        atrelado1.mostrarInformacoes();
    }
}
