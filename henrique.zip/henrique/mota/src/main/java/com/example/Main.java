package com.example;

public class Main {

    public static void main(String[] args) {

        // Criar o objeto mota
        Mota mota1 = new Mota(
                "Yamaha",
                "MT-07",
                "Azul",
                2,
                "Gasolina",
                689,
                74,
                2024,
                8000,
                9500,
                220,
                "Manual",
                6,
                184,
                2.14,
                1.09,
                0.75,
                "Naked"
        );


        // Mostrar informações iniciais
        mota1.mostrarInformacoes();


        // Testar o comportamento da mota
        mota1.andar();

        mota1.ligar();

        mota1.andar();

        mota1.acelerar();

        mota1.acelerar();

        mota1.travar();

        mota1.travar();

        mota1.travar();

        mota1.desligar();
    }
}
