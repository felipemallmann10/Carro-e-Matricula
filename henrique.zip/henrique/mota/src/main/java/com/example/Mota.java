package com.example;

public class Mota {

    // =========================
    // ATRIBUTOS
    // =========================

    private String marca;
    private String modelo;
    private String cor;

    private int numeroLugares;

    private String tipoCombustivel;
    private double cilindrada;
    private int potencia;

    private int ano;
    private double quilometragem;
    private double preco;

    private int velocidadeMaxima;
    private int velocidadeAtual;

    private String tipoCaixa;
    private int numeroMudancas;

    private double peso;
    private double comprimento;
    private double altura;
    private double largura;

    private String tipoMota;

    private boolean ligado;


    // =========================
    // CONSTRUTOR
    // =========================

    public Mota(
            String marca,
            String modelo,
            String cor,
            int numeroLugares,
            String tipoCombustivel,
            double cilindrada,
            int potencia,
            int ano,
            double quilometragem,
            double preco,
            int velocidadeMaxima,
            String tipoCaixa,
            int numeroMudancas,
            double peso,
            double comprimento,
            double altura,
            double largura,
            String tipoMota) {

        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;

        this.numeroLugares = numeroLugares;

        this.tipoCombustivel = tipoCombustivel;
        this.cilindrada = cilindrada;
        this.potencia = potencia;

        this.ano = ano;
        this.quilometragem = quilometragem;
        this.preco = preco;

        this.velocidadeMaxima = velocidadeMaxima;
        this.velocidadeAtual = 0;

        this.tipoCaixa = tipoCaixa;
        this.numeroMudancas = numeroMudancas;

        this.peso = peso;
        this.comprimento = comprimento;
        this.altura = altura;
        this.largura = largura;

        this.tipoMota = tipoMota;

        // A mota começa sempre desligada
        this.ligado = false;
    }


    // =========================
    // MÉTODOS
    // =========================

    public void ligar() {

        if (!ligado) {
            ligado = true;
            System.out.println("A mota foi ligada.");
        } else {
            System.out.println("A mota já está ligada.");
        }
    }


    public void desligar() {

        if (velocidadeAtual > 0) {
            System.out.println("Não é possível desligar a mota enquanto está em movimento.");
        } else if (ligado) {
            ligado = false;
            System.out.println("A mota foi desligada.");
        } else {
            System.out.println("A mota já está desligada.");
        }
    }


    public void andar() {

        if (!ligado) {
            System.out.println("A mota não pode andar porque está desligada.");
        } else {
            velocidadeAtual = 10;
            System.out.println("A mota começou a andar.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " km/h");
        }
    }


    public void acelerar() {

        if (!ligado) {
            System.out.println("A mota está desligada.");
        } else if (velocidadeAtual >= velocidadeMaxima) {
            System.out.println("A mota já atingiu a velocidade máxima.");
        } else {
            velocidadeAtual += 10;

            if (velocidadeAtual > velocidadeMaxima) {
                velocidadeAtual = velocidadeMaxima;
            }

            System.out.println("A mota acelerou.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " km/h");
        }
    }


    public void travar() {

        if (velocidadeAtual == 0) {
            System.out.println("A mota já está parada.");
        } else {
            velocidadeAtual -= 10;

            if (velocidadeAtual < 0) {
                velocidadeAtual = 0;
            }

            System.out.println("A mota travou.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " km/h");
        }
    }


    // =========================
    // MOSTRAR INFORMAÇÕES
    // =========================

    public void mostrarInformacoes() {

        System.out.println("================================");
        System.out.println("       INFORMAÇÕES DA MOTA");
        System.out.println("================================");

        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Cor: " + cor);

        System.out.println("Número de lugares: " + numeroLugares);

        System.out.println("Tipo de combustível: " + tipoCombustivel);
        System.out.println("Cilindrada: " + cilindrada + " cc");
        System.out.println("Potência: " + potencia + " cv");

        System.out.println("Ano: " + ano);
        System.out.println("Quilometragem: " + quilometragem + " km");
        System.out.println("Preço: " + preco + " €");

        System.out.println("Velocidade máxima: " + velocidadeMaxima + " km/h");
        System.out.println("Velocidade atual: " + velocidadeAtual + " km/h");

        System.out.println("Tipo de caixa: " + tipoCaixa);
        System.out.println("Número de mudanças: " + numeroMudancas);

        System.out.println("Peso: " + peso + " kg");
        System.out.println("Comprimento: " + comprimento + " m");
        System.out.println("Altura: " + altura + " m");
        System.out.println("Largura: " + largura + " m");

        System.out.println("Tipo de mota: " + tipoMota);

        if (ligado) {
            System.out.println("Estado: Ligado");
        } else {
            System.out.println("Estado: Desligado");
        }

        System.out.println("================================");
    }
}
