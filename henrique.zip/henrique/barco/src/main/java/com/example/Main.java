package com.example;

public class Main {

    public static void main(String[] args) {

        // Criar o objeto barco
        barco barco1 = new barco(
                "Bayliner",
                "VR6",
                "Branco",
                8,
                1,
                "Gasolina",
                4.5,
                300,
                2023,
                120,
                85000,
                45,
                "Motor de popa",
                2200,
                6.7,
                0.9,
                2.5,
                "Lancha"
        );


        // Mostrar informações iniciais
        barco1.mostrarInformacoes();


        // Testar o comportamento do barco
        barco1.andar();

        barco1.ligar();

        barco1.andar();

        barco1.acelerar();

        barco1.acelerar();

        barco1.travar();

        barco1.travar();

        barco1.travar();

        barco1.desligar();
    }
}
