package com.example;

public class barco {

    // =========================
    // ATRIBUTOS
    // =========================

    private String marca;
    private String modelo;
    private String cor;

    private int numeroLugares;
    private int numeroTripulantes;

    private String tipoCombustivel;
    private double cilindrada;
    private int potencia;

    private int ano;
    private double horasDeUso;
    private double preco;

    private int velocidadeMaxima;
    private int velocidadeAtual;

    private String tipoPropulsao;

    private double peso;
    private double comprimento;
    private double calado;
    private double largura;

    private String tipoBarco;

    private boolean ligado;


    // =========================
    // CONSTRUTOR
    // =========================

    public barco(
            String marca,
            String modelo,
            String cor,
            int numeroLugares,
            int numeroTripulantes,
            String tipoCombustivel,
            double cilindrada,
            int potencia,
            int ano,
            double horasDeUso,
            double preco,
            int velocidadeMaxima,
            String tipoPropulsao,
            double peso,
            double comprimento,
            double calado,
            double largura,
            String tipoBarco) {

        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;

        this.numeroLugares = numeroLugares;
        this.numeroTripulantes = numeroTripulantes;

        this.tipoCombustivel = tipoCombustivel;
        this.cilindrada = cilindrada;
        this.potencia = potencia;

        this.ano = ano;
        this.horasDeUso = horasDeUso;
        this.preco = preco;

        this.velocidadeMaxima = velocidadeMaxima;
        this.velocidadeAtual = 0;

        this.tipoPropulsao = tipoPropulsao;

        this.peso = peso;
        this.comprimento = comprimento;
        this.calado = calado;
        this.largura = largura;

        this.tipoBarco = tipoBarco;

        // O barco começa sempre desligado
        this.ligado = false;
    }


    // =========================
    // MÉTODOS
    // =========================

    public void ligar() {

        if (!ligado) {
            ligado = true;
            System.out.println("O barco foi ligado.");
        } else {
            System.out.println("O barco já está ligado.");
        }
    }


    public void desligar() {

        if (velocidadeAtual > 0) {
            System.out.println("Não é possível desligar o barco enquanto está em movimento.");
        } else if (ligado) {
            ligado = false;
            System.out.println("O barco foi desligado.");
        } else {
            System.out.println("O barco já está desligado.");
        }
    }


    public void andar() {

        if (!ligado) {
            System.out.println("O barco não pode navegar porque está desligado.");
        } else {
            velocidadeAtual = 5;
            System.out.println("O barco começou a navegar.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " nós");
        }
    }


    public void acelerar() {

        if (!ligado) {
            System.out.println("O barco está desligado.");
        } else if (velocidadeAtual >= velocidadeMaxima) {
            System.out.println("O barco já atingiu a velocidade máxima.");
        } else {
            velocidadeAtual += 5;

            if (velocidadeAtual > velocidadeMaxima) {
                velocidadeAtual = velocidadeMaxima;
            }

            System.out.println("O barco acelerou.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " nós");
        }
    }


    public void travar() {

        if (velocidadeAtual == 0) {
            System.out.println("O barco já está parado.");
        } else {
            velocidadeAtual -= 5;

            if (velocidadeAtual < 0) {
                velocidadeAtual = 0;
            }

            System.out.println("O barco reduziu a velocidade.");
            System.out.println("Velocidade atual: " + velocidadeAtual + " nós");
        }
    }


    // =========================
    // MOSTRAR INFORMAÇÕES
    // =========================

    public void mostrarInformacoes() {

        System.out.println("================================");
        System.out.println("       INFORMAÇÕES DO BARCO");
        System.out.println("================================");

        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Cor: " + cor);

        System.out.println("Número de lugares: " + numeroLugares);
        System.out.println("Número de tripulantes: " + numeroTripulantes);

        System.out.println("Tipo de combustível: " + tipoCombustivel);
        System.out.println("Cilindrada: " + cilindrada + " L");
        System.out.println("Potência: " + potencia + " cv");

        System.out.println("Ano: " + ano);
        System.out.println("Horas de uso: " + horasDeUso + " h");
        System.out.println("Preço: " + preco + " €");

        System.out.println("Velocidade máxima: " + velocidadeMaxima + " nós");
        System.out.println("Velocidade atual: " + velocidadeAtual + " nós");

        System.out.println("Tipo de propulsão: " + tipoPropulsao);

        System.out.println("Peso: " + peso + " kg");
        System.out.println("Comprimento: " + comprimento + " m");
        System.out.println("Calado: " + calado + " m");
        System.out.println("Largura: " + largura + " m");

        System.out.println("Tipo de barco: " + tipoBarco);

        if (ligado) {
            System.out.println("Estado: Ligado");
        } else {
            System.out.println("Estado: Desligado");
        }

        System.out.println("================================");
    }
}
