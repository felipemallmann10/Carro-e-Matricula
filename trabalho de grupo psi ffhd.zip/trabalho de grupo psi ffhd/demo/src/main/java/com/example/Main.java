package com.example;

import java.io.*;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Main {


static class Matricula {

    private String numero;
    private String pais;
    private int ano;

    private static final String FICHEIRO = "matriculas.txt";
    private static final Set<String> matriculasExistentes = carregarMatriculas();
    private static final Random random = new Random();

    public Matricula(String pais, int ano) {
        this.numero = gerarNumeroUnico();
        this.pais = pais;
        this.ano = ano;
    }

    private String gerarNumeroUnico() {

        String novaMatricula;

        do {
            int numero1 = random.nextInt(100);
            int numero2 = random.nextInt(100);

            char letra1 = (char) ('A' + random.nextInt(26));
            char letra2 = (char) ('A' + random.nextInt(26));

            novaMatricula = String.format(
                "%02d-%c%c-%02d",
                numero1,
                letra1,
                letra2,
                numero2
            );

        } while (matriculasExistentes.contains(novaMatricula));

        matriculasExistentes.add(novaMatricula);
        guardarMatricula(novaMatricula);

        return novaMatricula;
    }

    private static Set<String> carregarMatriculas() {

        Set<String> matriculas = new HashSet<>();

        File ficheiro = new File(FICHEIRO);

        if (!ficheiro.exists()) {
            return matriculas;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(ficheiro))) {

            String linha;

            while ((linha = reader.readLine()) != null) {
                matriculas.add(linha);
            }

        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar as matrículas.", e);
        }

        return matriculas;
    }

    private static void guardarMatricula(String numero) {

        try (FileWriter writer = new FileWriter(FICHEIRO, true)) {

            writer.write(numero + System.lineSeparator());

        } catch (IOException e) {
            throw new RuntimeException("Erro ao guardar a matrícula.", e);
        }
    }

    public void mostrarMatricula() {

        System.out.println("Matrícula: " + numero);
        System.out.println("País: " + pais);
        System.out.println("Ano: " + ano);
    }
}

public static void main(String[] args) {

    String pais = "São Tomé";
    int ano = 2009;

    Matricula matricula = new Matricula(pais, ano);

    System.out.println("=== MATRÍCULA GERADA AUTOMATICAMENTE ===");
    matricula.mostrarMatricula();
}


}
