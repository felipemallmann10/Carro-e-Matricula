package com.example;

public class Matricula {

    private String numero;
    private String pais;
    private int ano;

    public Matricula(String numero, String pais, int ano) {
        this.numero = numero;
        this.pais = pais;
        this.ano = ano;
    }

    public String getNumero() {
        return numero;
    }

    public String getPais() {
        return pais;
    }

    public int getAno() {
        return ano;
    }

    public void mostrarMatricula() {
        System.out.println("Matrícula: " + numero);
        System.out.println("País: " + pais);
        System.out.println("Ano: " + ano);
    }
}