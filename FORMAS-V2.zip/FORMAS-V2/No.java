import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.AbstractMap;

public class No {

    private String valor;
    private List<Map.Entry<No, Double>> arestas;

    public No(String valor) {
        this.valor = valor;
        this.arestas = new ArrayList<>();
    }

    public String getValor() {
        return valor;
    }

    public List<Map.Entry<No, Double>> getArestas() {
        return arestas;
    }

    public void ligarA(No destino, double custo) {
        arestas.add(
            new AbstractMap.SimpleEntry<>(destino, custo)
        );
    }

    public void mostrar() {
        System.out.println("No: " + valor);

        if (arestas.isEmpty()) {
            System.out.println("  Sem arestas de saida.");
            return;
        }

        for (Map.Entry<No, Double> aresta : arestas) {
            System.out.println(
                "  Vai para: " + aresta.getKey().getValor()
                + " | Custo: " + aresta.getValue()
            );
        }
    }
}