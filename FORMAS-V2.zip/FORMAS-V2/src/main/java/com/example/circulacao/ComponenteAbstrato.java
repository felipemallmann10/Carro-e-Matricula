
package com.example.circulacao;

public abstract class ComponenteAbstrato implements Acao {

    private boolean ativo;

    public ComponenteAbstrato() {
        this.ativo = true;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void ativar() {
        ativo = true;
    }

    public void desativar() {
        ativo = false;
    }

    @Override
    public boolean executar() {
        if (!ativo) {
            return false;
        }

        return executarAcao();
    }

    protected abstract boolean executarAcao();
}
