
package com.example.circulacao;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RedeCiclos {

    private final List<Ciclo> ciclos;
    private final List<Ligacao> ligacoes;

    public RedeCiclos() {
        this.ciclos = new ArrayList<>();
        this.ligacoes = new ArrayList<>();
    }

    public void adicionarCiclo(Ciclo ciclo) {
        if (ciclo == null) {
            throw new IllegalArgumentException(
                "O ciclo não pode ser nulo."
            );
        }

        if (obterCiclo(ciclo.getId()) != null) {
            throw new IllegalArgumentException(
                "Já existe um ciclo com esse ID."
            );
        }

        ciclos.add(ciclo);
        ciclos.sort(
            Comparator.comparingInt(Ciclo::getPrioridade)
        );
    }

    public Ciclo obterCiclo(int id) {
        for (Ciclo ciclo : ciclos) {
            if (ciclo.getId() == id) {
                return ciclo;
            }
        }

        return null;
    }

    public void adicionarLigacao(Ligacao ligacao) {
        if (ligacao == null) {
            throw new IllegalArgumentException(
                "A ligação não pode ser nula."
            );
        }

        if (obterCiclo(ligacao.getCicloOrigem()) == null
                || obterCiclo(ligacao.getCicloDestino()) == null) {
            throw new IllegalArgumentException(
                "Os dois ciclos da ligação têm de existir."
            );
        }

        ligacoes.add(ligacao);
    }

    public List<Ciclo> getCiclos() {
        return new ArrayList<>(ciclos);
    }

    public List<Ligacao> getLigacoes() {
        return new ArrayList<>(ligacoes);
    }

    public void mostrarRede() {
        System.out.println("=== CICLOS ===");

        for (Ciclo ciclo : ciclos) {
            System.out.println(ciclo);
        }

        System.out.println("=== LIGAÇÕES ===");

        for (Ligacao ligacao : ligacoes) {
            System.out.println(ligacao);
        }
    }
}

