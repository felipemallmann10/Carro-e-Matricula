
package com.example.circulacao;

public class Ciclo {

    private final int id;
    private final int prioridade;
    private final Espaco[] espacos;

    public Ciclo(int id, int prioridade) {
        if (id < 1) {
            throw new IllegalArgumentException(
                "O ID do ciclo deve ser positivo."
            );
        }

        if (prioridade < 1) {
            throw new IllegalArgumentException(
                "A prioridade deve ser positiva."
            );
        }

        this.id = id;
        this.prioridade = prioridade;
        this.espacos = new Espaco[5];

        for (int i = 0; i < espacos.length; i++) {
            espacos[i] = new Espaco(i + 1);
        }
    }

    public int getId() {
        return id;
    }

    public int getPrioridade() {
        return prioridade;
    }

    public Espaco getEspaco(int posicao) {
        if (posicao < 1 || posicao > 5) {
            throw new IllegalArgumentException(
                "A posição deve estar entre 1 e 5."
            );
        }

        return espacos[posicao - 1];
    }

    public void colocarLetra(int posicao, String letra) {
        getEspaco(posicao).colocarLetra(letra);
    }

    public String retirarLetra(int posicao) {
        return getEspaco(posicao).retirarLetra();
    }

    @Override
    public String toString() {
        StringBuilder resultado = new StringBuilder();

        resultado.append("Ciclo ").append(id)
                 .append(" (prioridade ")
                 .append(prioridade).append("): ");

        for (Espaco espaco : espacos) {
            resultado.append(espaco).append(" ");
        }

        return resultado.toString().trim();
    }
}
