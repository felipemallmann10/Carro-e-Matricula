
package com.example.circulacao;

public class CirculacaoController {

    private final ComponenteMotor componente;
    private final CirculacaoView view;
    private final MotorMovimentos motor;

    public CirculacaoController(
            ComponenteMotor componente,
            CirculacaoView view,
            MotorMovimentos motor) {

        if (componente == null || view == null || motor == null) {
            throw new IllegalArgumentException(
                "Os componentes do controlador nao podem ser nulos."
            );
        }

        this.componente = componente;
        this.view = view;
        this.motor = motor;
    }

    public void executarMovimento() {
        boolean resultado = componente.executar();

        view.mostrarResultado(resultado);
        view.mostrarEstado(motor);
    }

    public void desativarComponente() {
        componente.desativar();
    }

    public void ativarComponente() {
        componente.ativar();
    }
}
