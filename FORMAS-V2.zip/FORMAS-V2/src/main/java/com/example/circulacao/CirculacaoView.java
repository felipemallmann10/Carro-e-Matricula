
package com.example.circulacao;

public class CirculacaoView {

    public void mostrarTitulo(String titulo) {
        System.out.println();
        System.out.println("=== " + titulo + " ===");
    }

    public void mostrarResultado(boolean resultado) {
        if (resultado) {
            System.out.println("Movimento executado.");
        } else {
            System.out.println(
                "Movimento nao executado ou componente inativo."
            );
        }
    }

    public void mostrarEstado(MotorMovimentos motor) {
        motor.mostrarEstado();
    }
}
