
package com.example.circulacao;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MotorMovimentos {

    private final RedeCiclos rede;

    public MotorMovimentos(RedeCiclos rede) {
        if (rede == null) {
            throw new IllegalArgumentException(
                "A rede de ciclos não pode ser nula."
            );
        }

        this.rede = rede;
    }

    public RedeCiclos getRede() {
        return rede;
    }

    public void executarMovimento(Ligacao ligacao) {
        if (ligacao == null) {
            throw new IllegalArgumentException(
                "A ligação não pode ser nula."
            );
        }

        if (!rede.getLigacoes().contains(ligacao)) {
            throw new IllegalArgumentException(
                "A ligação não pertence à rede."
            );
        }

        Ciclo origem = rede.obterCiclo(
            ligacao.getCicloOrigem()
        );

        Ciclo destino = rede.obterCiclo(
            ligacao.getCicloDestino()
        );

        Espaco espacoOrigem = origem.getEspaco(
            ligacao.getPosicaoOrigem()
        );

        Espaco espacoDestino = destino.getEspaco(
            ligacao.getPosicaoDestino()
        );

        if (origem == destino
                && ligacao.getPosicaoOrigem()
                == ligacao.getPosicaoDestino()) {
            throw new IllegalArgumentException(
                "A origem e o destino não podem ser iguais."
            );
        }

        if (espacoOrigem.estaVazio()) {
            throw new IllegalStateException(
                "Não existe nenhuma letra na origem."
            );
        }

        String letraOrigem = espacoOrigem.getLetra();
        String letraDestino = espacoDestino.getLetra();

        espacoOrigem.retirarLetra();

        if (!espacoDestino.estaVazio()) {
            espacoDestino.retirarLetra();
        }

        espacoDestino.colocarLetra(letraOrigem);

        if (letraDestino != null) {
            espacoOrigem.colocarLetra(letraDestino);
        }
    }

    public List<Ligacao> obterMovimentosDisponiveis() {
        List<Ligacao> disponiveis = new ArrayList<>();

        for (Ligacao ligacao : rede.getLigacoes()) {
            Ciclo origem = rede.obterCiclo(
                ligacao.getCicloOrigem()
            );

            if (origem == null) {
                continue;
            }

            Espaco espacoOrigem = origem.getEspaco(
                ligacao.getPosicaoOrigem()
            );

            if (!espacoOrigem.estaVazio()) {
                disponiveis.add(ligacao);
            }
        }

        disponiveis.sort(
            Comparator.comparingInt(
                ligacao -> rede.obterCiclo(
                    ligacao.getCicloOrigem()
                ).getPrioridade()
            )
        );

        return disponiveis;
    }

    public boolean executarProximoMovimento() {
        List<Ligacao> movimentos = obterMovimentosDisponiveis();

        if (movimentos.isEmpty()) {
            return false;
        }

        executarMovimento(movimentos.get(0));
        return true;
    }

    public void mostrarEstado() {
        rede.mostrarRede();
    }
}
