
package com.example.circulacao;

public interface Acao {

    boolean executar();
}
