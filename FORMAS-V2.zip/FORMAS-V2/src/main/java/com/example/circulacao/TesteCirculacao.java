
package com.example.circulacao;

public class TesteCirculacao {

    public static void main(String[] args) {

        RedeCiclos rede = new RedeCiclos();

        Ciclo ciclo1 = new Ciclo(1, 1);
        Ciclo ciclo2 = new Ciclo(2, 2);

        rede.adicionarCiclo(ciclo1);
        rede.adicionarCiclo(ciclo2);

        System.out.println("=== TESTE DE LIGACAO VALIDA ===");

        try {
            rede.adicionarLigacao(
                new Ligacao(1, 1, 2, 5)
            );

            System.out.println("Ligacao valida aceite.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        System.out.println();
        System.out.println("=== TESTE DE CICLO INEXISTENTE ===");

        try {
            rede.adicionarLigacao(
                new Ligacao(1, 1, 99, 5)
            );

            System.out.println("Erro: ligacao invalida aceite.");
        } catch (IllegalArgumentException e) {
            System.out.println("Ligacao rejeitada: " + e.getMessage());
        }

        System.out.println();
        System.out.println("=== REDE FINAL ===");
        rede.mostrarRede();
    }
}
