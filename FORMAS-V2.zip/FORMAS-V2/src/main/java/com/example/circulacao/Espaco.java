
package com.example.circulacao;

public class Espaco {

    private final int posicao;
    private String letra;

    public Espaco(int posicao) {
        if (posicao < 1 || posicao > 5) {
            throw new IllegalArgumentException(
                "A posição deve estar entre 1 e 5."
            );
        }

        this.posicao = posicao;
        this.letra = null;
    }

    public int getPosicao() {
        return posicao;
    }

    public String getLetra() {
        return letra;
    }

    public boolean estaVazio() {
        return letra == null;
    }

    public void colocarLetra(String letra) {
        if (letra == null || letra.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "A letra não pode ser vazia."
            );
        }

        if (!estaVazio()) {
            throw new IllegalStateException(
                "O espaço já está ocupado."
            );
        }

        this.letra = letra;
    }

    public String retirarLetra() {
        if (estaVazio()) {
            throw new IllegalStateException(
                "O espaço já está vazio."
            );
        }

        String letraRetirada = letra;
        letra = null;

        return letraRetirada;
    }

    @Override
    public String toString() {
        return letra == null ? "[ ]" : "[" + letra + "]";
    }
}

