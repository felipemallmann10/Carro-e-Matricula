
package com.example.circulacao;

public class ComponenteMotor extends ComponenteAbstrato {

    private final MotorMovimentos motor;

    public ComponenteMotor(MotorMovimentos motor) {
        if (motor == null) {
            throw new IllegalArgumentException(
                "O motor não pode ser nulo."
            );
        }

        this.motor = motor;
    }

    @Override
    protected boolean executarAcao() {
        return motor.executarProximoMovimento();
    }
}
