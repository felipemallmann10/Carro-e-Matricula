
package com.example.circulacao;

public class Ligacao {

    private final int cicloOrigem;
    private final int posicaoOrigem;
    private final int cicloDestino;
    private final int posicaoDestino;

    public Ligacao(
            int cicloOrigem,
            int posicaoOrigem,
            int cicloDestino,
            int posicaoDestino) {

        if (cicloOrigem < 1 || cicloDestino < 1) {
            throw new IllegalArgumentException(
                "Os IDs dos ciclos devem ser positivos."
            );
        }

        validarPosicao(posicaoOrigem);
        validarPosicao(posicaoDestino);

        this.cicloOrigem = cicloOrigem;
        this.posicaoOrigem = posicaoOrigem;
        this.cicloDestino = cicloDestino;
        this.posicaoDestino = posicaoDestino;
    }

    private void validarPosicao(int posicao) {
        if (posicao < 1 || posicao > 5) {
            throw new IllegalArgumentException(
                "A posição deve estar entre 1 e 5."
            );
        }
    }

    public int getCicloOrigem() {
        return cicloOrigem;
    }

    public int getPosicaoOrigem() {
        return posicaoOrigem;
    }

    public int getCicloDestino() {
        return cicloDestino;
    }

    public int getPosicaoDestino() {
        return posicaoDestino;
    }

    @Override
    public String toString() {
        return "Ciclo " + cicloOrigem + ", posição "
            + posicaoOrigem + " -> Ciclo " + cicloDestino
            + ", posição " + posicaoDestino;
    }
}
